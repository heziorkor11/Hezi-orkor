(function () {
  const { brand, categories, partTypes, products, reviews } = window.HEZI;
  const $ = (sel, root = document) => root.querySelector(sel);
  const app = $("#app");
  const cartCount = $("#cart-count");

  const money = (n) => "₪" + Number(n).toLocaleString("he-IL");
  const glyph = (type) =>
    ({
      headlight: "💡",
      taillight: "🔴",
      foglight: "🔦",
      mirror: "🪞",
      compressor: "❄️",
      condenser: "🌬️",
      radiator: "🌡️",
      fender: "🚗",
      bumper: "🛡️",
      battery: "🔋",
      accessory: "🧰",
    }[type] || "🧩");

  function cart() {
    try {
      return JSON.parse(localStorage.getItem("hezi-cart") || "[]");
    } catch {
      return [];
    }
  }
  function saveCart(items) {
    localStorage.setItem("hezi-cart", JSON.stringify(items));
    renderCartCount();
  }
  function addToCart(id, qty = 1) {
    const items = cart();
    const found = items.find((x) => x.id === id);
    if (found) found.qty += qty;
    else items.push({ id, qty });
    saveCart(items);
  }
  function renderCartCount() {
    const n = cart().reduce((s, x) => s + x.qty, 0);
    cartCount.textContent = n;
    cartCount.style.display = n ? "grid" : "none";
  }

  function unique(arr) {
    return [...new Set(arr.filter(Boolean))];
  }

  function filterProducts({ type, make, model, year, q, category }) {
    return products.filter((p) => {
      if (category && p.category !== category) return false;
      if (type && p.type !== type) return false;
      if (make && p.make !== make) return false;
      if (model && p.model !== model) return false;
      if (year) {
        const y = Number(year);
        if (!p.universal && (y < p.yearFrom || y > p.yearTo)) return false;
      }
      if (q) {
        const s = q.trim().toLowerCase();
        const blob = [p.name, p.sku, p.oe, p.make, p.model, p.side, p.description]
          .join(" ")
          .toLowerCase();
        if (!blob.includes(s)) return false;
      }
      return true;
    });
  }

  function productCard(p) {
    return `
      <article class="card">
        <div class="thumb">
          <span class="sku-chip">מק״ט ${p.sku}</span>
          <div class="part-glyph">${glyph(p.type)}</div>
        </div>
        <div class="card-body">
          <h3><a href="#/product/${p.id}">${p.name}</a></h3>
          <div class="meta">
            ${p.side ? `<span>צד: <b>${p.side}</b></span>` : ""}
            ${p.yearFrom ? `<span>שנים: <b>${p.yearFrom}–${p.yearTo}</b></span>` : `<span class="badge">אוניברסלי</span>`}
          </div>
          <div class="price-row">
            <span class="price">${money(p.price)}</span>
            ${p.originalPrice ? `<span class="was">${money(p.originalPrice)}</span>` : ""}
          </div>
          <div class="actions">
            <button class="btn btn-primary" data-add="${p.id}">הוסף לסל</button>
            <a class="btn btn-ghost" href="#/product/${p.id}">פרטים</a>
          </div>
        </div>
      </article>`;
  }

  function demoNote() {
    return `<div class="demo-banner">זו גרסת הדגמה. המוצרים והמחירים לדוגמה בלבד — לא מלאי אמיתי של המוסך. אחרי חיבור המאסטר-קטלוג העמודים האלה מתמלאים בחלקים שלכם.</div>`;
  }

  function finderBar(state = {}) {
    const types = partTypes;
    const makes = unique(products.map((p) => p.make));
    const models = unique(
      products.filter((p) => !state.make || p.make === state.make).map((p) => p.model)
    );
    const years = [];
    products.forEach((p) => {
      if (state.make && p.make !== state.make) return;
      if (state.model && p.model !== state.model) return;
      if (p.yearFrom) {
        for (let y = p.yearFrom; y <= p.yearTo; y++) years.push(y);
      }
    });
    const yearOpts = unique(years).sort((a, b) => b - a);

    return `
      <form class="finder" id="finder">
        <label>1 · סוג חלק
          <select name="type">
            <option value="">בחר סוג חלק</option>
            ${types.map((t) => `<option value="${t.id}" ${state.type === t.id ? "selected" : ""}>${t.name}</option>`).join("")}
          </select>
        </label>
        <label>2 · יצרן רכב
          <select name="make">
            <option value="">בחר יצרן</option>
            ${makes.map((m) => `<option ${state.make === m ? "selected" : ""}>${m}</option>`).join("")}
          </select>
        </label>
        <label>3 · דגם
          <select name="model">
            <option value="">בחר דגם</option>
            ${models.map((m) => `<option ${state.model === m ? "selected" : ""}>${m}</option>`).join("")}
          </select>
        </label>
        <label>4 · שנה
          <select name="year">
            <option value="">בחר שנה</option>
            ${yearOpts.map((y) => `<option ${String(state.year) === String(y) ? "selected" : ""}>${y}</option>`).join("")}
          </select>
        </label>
        <button class="go" type="submit">חפש</button>
      </form>
      <div class="finder-help">
        <span>לא בטוחים? חפשו לפי מק״ט למעלה, או שלחו תמונה בוואטסאפ.</span>
        <a href="#/help">לא מצאת? לחץ כאן</a>
      </div>`;
  }

  function home() {
    const featured = products.slice(0, 8);
    app.innerHTML = `
      <section class="hero">
        <div class="hero-media">
          <video autoplay muted loop playsinline poster="img/logo.jpg">
            <source src="img/logo-loop.mp4" type="video/mp4" />
          </video>
        </div>
        <h1>Hezi Orkor</h1>
        <p class="tag">WE FIX EVERYTHING</p>
        <p class="hebrew-line">חלפים ואביזרים לרכב — מוצאים מהר, בלי לנחש</p>
        ${finderBar()}
      </section>
      <div class="trust">
        <div>משלוח נוח<span>₪${brand.shipping} · חינם מ־${money(brand.freeShipFrom)}</span></div>
        <div>אספקה מהירה<span>איסוף או שליח</span></div>
        <div>התאמה לפי רכב<span>סוג חלק → יצרן → דגם → שנה</span></div>
        <div>אדם בצד השני<span>וואטסאפ ${brand.phone}</span></div>
      </div>
      <div class="wrap">
        ${demoNote()}
        <div class="section-head">
          <div>
            <h2>חלקים שמוצאים בעין</h2>
            <p>תמונה, מק״ט, צד ושנים — בלי לנחש.</p>
          </div>
        </div>
        <div class="grid">${featured.map(productCard).join("")}</div>
        <div class="section-head" style="margin-top:36px">
          <div><h2>מה אומרים לקוחות</h2><p>הפסיכולוגיה פשוטה: להוריד פחד מטעות.</p></div>
        </div>
        <div class="reviews">
          ${reviews
            .map(
              (r) => `<div class="review"><div class="stars">${"★".repeat(r.stars)}</div><p>${r.text}</p><strong>${r.name}</strong></div>`
            )
            .join("")}
        </div>
      </div>`;
    wireFinder();
  }

  function wireFinder() {
    const form = $("#finder");
    if (!form) return;
    form.addEventListener("change", (e) => {
      if (e.target.name === "make") {
        form.model.value = "";
        form.year.value = "";
      }
      if (e.target.name === "model") form.year.value = "";
      const state = {
        type: form.type.value,
        make: form.make.value,
        model: form.model.value,
        year: form.year.value,
      };
      form.outerHTML = finderBar(state);
      wireFinder();
    });
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const q = new URLSearchParams({
        type: form.type.value,
        make: form.make.value,
        model: form.model.value,
        year: form.year.value,
      });
      location.hash = "#/results?" + q.toString();
    });
  }

  function resultsPage() {
    const params = new URLSearchParams(location.hash.split("?")[1] || "");
    const state = {
      type: params.get("type") || "",
      make: params.get("make") || "",
      model: params.get("model") || "",
      year: params.get("year") || "",
      q: params.get("q") || "",
      category: params.get("category") || "",
    };
    const list = filterProducts(state);
    const title = state.q
      ? `חיפוש: ${state.q}`
      : state.category
      ? categories.find((c) => c.id === state.category)?.name || "קטגוריה"
      : "תוצאות לפי הרכב";
    app.innerHTML = `
      <section class="hero" style="padding:28px">
        ${finderBar(state)}
      </section>
      <div class="wrap">
        ${demoNote()}
        <div class="section-head">
          <div>
            <h2>${title}</h2>
            <p>${list.length} חלקים תואמים</p>
          </div>
        </div>
        ${
          list.length
            ? `<div class="grid">${list.map(productCard).join("")}</div>`
            : `<div class="notice">
                <h3>לא מצאנו התאמה בקטלוג הדמו</h3>
                <p>שלחו לנו מק״ט, תמונה או מספר רכב — נאתר את החלק.</p>
                <a class="btn btn-accent" href="#/help">לא מצאת? דברו איתנו</a>
              </div>`
        }
      </div>`;
    wireFinder();
  }

  function productPage(id) {
    const p = products.find((x) => x.id === id);
    if (!p) {
      app.innerHTML = `<div class="wrap"><div class="notice">המוצר לא נמצא. <a href="#/">חזרה</a></div></div>`;
      return;
    }
    const related = products.filter((x) => x.category === p.category && x.id !== p.id).slice(0, 4);
    app.innerHTML = `
      <div class="wrap">
        ${demoNote()}
        <div class="product-page">
          <div class="gallery"><div class="part-glyph" style="width:160px;height:160px;font-size:64px">${glyph(p.type)}</div></div>
          <div class="buy">
            <div class="meta"><span class="badge">${p.condition}</span></div>
            <h1>${p.name}</h1>
            <div class="price-row">
              <span class="price">${money(p.price)}</span>
              ${p.originalPrice ? `<span class="was">${money(p.originalPrice)}</span>` : ""}
            </div>
            <div class="spec">
              <span>מק״ט</span><b>${p.sku}</b>
              ${p.oe ? `<span>OE</span><b>${p.oe}</b>` : ""}
              ${p.side ? `<span>צד</span><b>${p.side}</b>` : ""}
              ${p.make ? `<span>רכב</span><b>${p.make} ${p.model} ${p.yearFrom}–${p.yearTo}</b>` : `<span>התאמה</span><b>אוניברסלי</b>`}
            </div>
            <p>${p.description}</p>
            <div class="qty">
              <button type="button" id="minus">−</button>
              <strong id="qty">1</strong>
              <button type="button" id="plus">+</button>
            </div>
            <div class="actions">
              <button class="btn btn-primary" id="add">הוסף לסל</button>
              <a class="btn btn-accent" target="_blank" href="https://wa.me/${brand.whatsapp}?text=${encodeURIComponent("שלום, רציתי לבדוק התאמה לחלק " + p.sku + " — " + p.name)}">בדקו איתי בוואטסאפ</a>
            </div>
          </div>
        </div>
        ${related.length ? `<div class="section-head" style="margin-top:28px"><div><h2>עוד באותה קטגוריה</h2></div></div><div class="grid">${related.map(productCard).join("")}</div>` : ""}
      </div>`;
    let qty = 1;
    $("#minus").onclick = () => {
      qty = Math.max(1, qty - 1);
      $("#qty").textContent = qty;
    };
    $("#plus").onclick = () => {
      qty += 1;
      $("#qty").textContent = qty;
    };
    $("#add").onclick = () => {
      addToCart(p.id, qty);
      $("#add").textContent = "נוסף לסל";
    };
  }

  function cartPage() {
    const items = cart()
      .map((c) => ({ ...c, product: products.find((p) => p.id === c.id) }))
      .filter((x) => x.product);
    const sum = items.reduce((s, x) => s + x.product.price * x.qty, 0);
    const ship = sum >= brand.freeShipFrom || sum === 0 ? 0 : brand.shipping;
    app.innerHTML = `
      <div class="wrap">
        <div class="section-head"><div><h2>סל הקניות</h2><p>${items.length} פריטים</p></div></div>
        ${
          items.length
            ? `<div class="cart-list">
                ${items
                  .map(
                    (x) => `<div class="cart-item">
                      <div><strong>${x.product.name}</strong><div class="meta">מק״ט ${x.product.sku} · כמות ${x.qty}</div></div>
                      <div class="price">${money(x.product.price * x.qty)}</div>
                      <button class="btn btn-ghost" data-remove="${x.id}">הסר</button>
                    </div>`
                  )
                  .join("")}
              </div>
              <div class="totals">
                <p>משלוח: <b>${ship ? money(ship) : "חינם"}</b> ${sum < brand.freeShipFrom && sum ? `(חינם מ־${money(brand.freeShipFrom)})` : ""}</p>
                <p>לתשלום: <span class="price">${money(sum + ship)}</span></p>
                <p class="meta">התשלום בגרסת הדמו לא מחובר לסליקה. ההזמנה נשלחת אלינו בוואטסאפ לאישור.</p>
                <a class="btn btn-accent" target="_blank" href="https://wa.me/${brand.whatsapp}?text=${encodeURIComponent(
                  "הזמנה מהאתר:\n" +
                    items.map((x) => `${x.product.sku} × ${x.qty} — ${x.product.name}`).join("\n") +
                    "\nסה״כ " +
                    (sum + ship) +
                    " ₪"
                )}">שליחה לאישור בוואטסאפ</a>
              </div>`
            : `<div class="empty">הסל ריק. <a href="#/">בחזרה לקטלוג</a></div>`
        }
      </div>`;
  }

  function helpPage() {
    app.innerHTML = `
      <div class="wrap">
        <div class="notice" style="text-align:right">
          <h2>לא מצאתם את החלק?</h2>
          <p>זה נורמלי. שלחו מספר רכב, מק״ט מהחלק הישן, או תמונה — ונאתר התאמה.</p>
          <form id="help-form" style="display:grid;gap:10px;margin-top:16px">
            <input name="plate" placeholder="מספר רכב / לוחית" style="padding:12px;border-radius:12px;border:1px solid #ddd">
            <input name="sku" placeholder="מק״ט / OE אם יש" style="padding:12px;border-radius:12px;border:1px solid #ddd">
            <input name="part" placeholder="איזה חלק צריך? למשל פנס אחורי שמאל" style="padding:12px;border-radius:12px;border:1px solid #ddd">
            <button class="btn btn-accent" type="submit">פתחו וואטסאפ עם הפרטים</button>
          </form>
        </div>
      </div>`;
    $("#help-form").onsubmit = (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const msg = `שלום, לא מצאתי באתר.\nמספר רכב: ${fd.get("plate")}\nמק״ט: ${fd.get("sku")}\nחלק: ${fd.get("part")}`;
      window.open("https://wa.me/" + brand.whatsapp + "?text=" + encodeURIComponent(msg), "_blank");
    };
  }

  function route() {
    const hash = location.hash || "#/";
    const [path] = hash.slice(1).split("?");
    const parts = path.split("/").filter(Boolean);
    if (parts[0] === "product" && parts[1]) productPage(parts[1]);
    else if (parts[0] === "results") resultsPage();
    else if (parts[0] === "cart") cartPage();
    else if (parts[0] === "help") helpPage();
    else if (parts[0] === "cat" && parts[1]) {
      location.replace("#/results?category=" + encodeURIComponent(parts[1]));
    } else home();
    window.scrollTo(0, 0);
  }

  document.body.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-add]");
    if (btn) addToCart(btn.getAttribute("data-add"));
    const rm = e.target.closest("[data-remove]");
    if (rm) {
      saveCart(cart().filter((x) => x.id !== rm.getAttribute("data-remove")));
      route();
    }
  });

  $("#site-search").addEventListener("submit", (e) => {
    e.preventDefault();
    const q = e.target.q.value.trim();
    location.hash = "#/results?q=" + encodeURIComponent(q);
  });

  window.addEventListener("hashchange", route);
  renderCartCount();
  route();
})();
